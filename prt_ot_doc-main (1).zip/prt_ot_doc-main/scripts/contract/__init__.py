"""Contract testing utilities."""
