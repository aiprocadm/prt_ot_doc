from __future__ import annotations

import json
import logging
import re
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from shutil import which
from typing import Annotated, Final, Literal

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from pydantic import (
    AliasChoices,
    BeforeValidator,
    Field,
    PrivateAttr,
    ValidationInfo,
    field_validator,
    model_validator,
)
from pydantic.fields import FieldInfo
from pydantic_core import PydanticUndefined, PydanticUndefinedType
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic_settings import sources as settings_sources

from app.core.i18n import configure_runtime_locale

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class RuntimeConfig:
    """Runtime mode toggles for different environments."""

    environment: Literal["development", "staging", "production", "test"]
    debug: bool

    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    @property
    def is_development(self) -> bool:
        return self.environment == "development"


@dataclass(frozen=True)
class ApplicationConfig:
    """Top-level application toggles and HTTP metadata."""

    name: str
    environment: Literal["development", "staging", "production", "test"]
    debug: bool
    secret_key: str
    api_prefix: str
    api_v1_prefix: str
    allowed_hosts: list[str]
    allowed_origins: list[str]
    default_locale: str
    default_timezone: str

    @property
    def runtime(self) -> RuntimeConfig:
        return RuntimeConfig(environment=self.environment, debug=self.debug)


@dataclass(frozen=True)
class DatabaseConfig:
    """Database connection parameters for SQLAlchemy and Alembic."""

    url: str
    alembic_url: str
    echo: bool
    host: str
    port: int
    name: str
    user: str
    password: str


@dataclass(frozen=True)
class BrokerConfig:
    """Message broker endpoints for Celery and rate limiting."""

    broker_url: str
    result_url: str
    rate_limit_storage_uri: str

    @property
    def has_dedicated_result_backend(self) -> bool:
        return self.result_url != self.broker_url


@dataclass(frozen=True)
class CeleryConfig:
    """Celery queues and execution limits."""

    worker_queues: list[str]
    pdf_queue: str
    task_soft_time_limit: int
    task_time_limit: int
    task_max_retries: int
    retry_backoff_seconds: int
    retry_backoff_max_seconds: int


@dataclass(frozen=True)
class LoggingConfig:
    """Logging format toggles."""

    level: str
    json_enabled: bool


def _generate_dev_keypair() -> tuple[str, str]:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    private_pem = key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    public_pem = (
        key.public_key()
        .public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        .decode("utf-8")
    )
    return private_pem, public_pem


DEV_PRIVATE_KEY, DEV_PUBLIC_KEY = _generate_dev_keypair()


JSON_MAX_DEFAULT: Final[int] = 1_048_576
MAX_UPLOAD_SIZE_DEFAULT: Final[int] = 20_971_520
DEFAULT_ALLOWED_HOSTS: Final[list[str]] = ["localhost", "127.0.0.1", "::1", "testserver"]
DEFAULT_ALLOWED_ORIGINS: Final[list[str]] = [
    "http://localhost",
    "http://localhost:5173",
    "http://127.0.0.1",
    "http://127.0.0.1:5173",
]

DEFAULT_ALLOWED_FILE_MIME: Final[list[str]] = [
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "text/plain",
    "image/png",
    "image/jpeg",
]

DEFAULT_ALLOWED_FILE_EXTENSIONS: Final[list[str]] = [
    "pdf",
    "doc",
    "docx",
    "txt",
    "png",
    "jpg",
    "jpeg",
]


def _parse_file_allowed_mime(value: object) -> list[str]:
    items = split_csv(value, default=DEFAULT_ALLOWED_FILE_MIME)
    normalized: list[str] = []
    for item in items:
        candidate = str(item).strip().lower()
        if not candidate:
            continue
        if candidate not in normalized:
            normalized.append(candidate)
    return normalized or list(DEFAULT_ALLOWED_FILE_MIME)


def _parse_file_allowed_extensions(value: object) -> list[str]:
    items = split_csv(value, default=DEFAULT_ALLOWED_FILE_EXTENSIONS)
    normalized: list[str] = []
    for item in items:
        candidate = str(item).strip().lower().lstrip(".")
        if not candidate:
            continue
        if not candidate.isascii():
            continue
        canonical = {"jpeg": "jpg"}.get(candidate, candidate)
        if canonical not in normalized:
            normalized.append(canonical)
    return normalized or list(DEFAULT_ALLOWED_FILE_EXTENSIONS)


CsvMimeList = Annotated[list[str], BeforeValidator(_parse_file_allowed_mime)]
CsvExtensionList = Annotated[list[str], BeforeValidator(_parse_file_allowed_extensions)]


def _tolerant_json_loads(value: str, *args, **kwargs) -> object:
    """Parse JSON values while tolerating plain strings."""

    try:
        return json.loads(value, *args, **kwargs)
    except (json.JSONDecodeError, TypeError):  # pragma: no cover - defensive fallback
        if args or kwargs:
            raise
        return value


def _decode_complex_value_with_fallback(
    self: settings_sources.PydanticBaseSettingsSource,
    field_name: str,
    field: FieldInfo,
    value: object,
) -> object:
    if isinstance(value, (str, bytes, bytearray)):
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return value
    return value


settings_sources.PydanticBaseSettingsSource.decode_complex_value = (
    _decode_complex_value_with_fallback
)


class SettingsError(RuntimeError):
    """Raised when critical configuration is missing."""


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        populate_by_name=True,
        extra="ignore",
    )

    _application: ApplicationConfig | None = PrivateAttr(default=None)
    _runtime: RuntimeConfig | None = PrivateAttr(default=None)
    _database: DatabaseConfig | None = PrivateAttr(default=None)
    _broker: BrokerConfig | None = PrivateAttr(default=None)
    _celery: CeleryConfig | None = PrivateAttr(default=None)
    _logging: LoggingConfig | None = PrivateAttr(default=None)

    app_name: str = Field("prt-ot-doc", alias="APP_NAME")
    app_env: Literal["development", "staging", "production", "test"] = Field(
        "development", alias="APP_ENV"
    )
    debug: bool = Field(False, alias="APP_DEBUG")

    api_prefix: str = Field("/api", alias="API_PREFIX")
    api_v1_prefix: str = Field("/api/v1", alias="API_V1_PREFIX")

    allowed_hosts: list[str] = Field(
        default_factory=lambda: list(DEFAULT_ALLOWED_HOSTS),
        alias="APP_TRUSTED_HOSTS",
        validation_alias=AliasChoices("APP_TRUSTED_HOSTS", "ALLOWED_HOSTS"),
    )
    allowed_origins: list[str] = Field(
        default_factory=lambda: list(DEFAULT_ALLOWED_ORIGINS),
        alias="APP_CORS_ORIGINS",
        validation_alias=AliasChoices("APP_CORS_ORIGINS", "ALLOWED_ORIGINS"),
    )

    database_url_env: str | None = Field(default=None, alias="DATABASE_URL")
    postgres_host: str = Field("postgres", alias="POSTGRES_HOST")
    postgres_port: int = Field(5432, alias="POSTGRES_PORT")
    postgres_db: str = Field("documents", alias="POSTGRES_DB")
    postgres_user: str = Field("app", alias="POSTGRES_USER")
    postgres_password: str = Field("change_me", alias="POSTGRES_PASSWORD")
    database_echo: bool = Field(False, alias="DATABASE_ECHO")
    default_tenant_slug: str = Field("public", alias="DEFAULT_TENANT_SLUG")
    shared_schema: str = Field("public", alias="SHARED_SCHEMA")

    s3_backend: Literal["memory", "minio"] = Field("memory", alias="S3_BACKEND")
    s3_endpoint: str = Field("http://minio:9000", alias="S3_ENDPOINT")
    s3_bucket: str = Field("documents", alias="S3_BUCKET")
    s3_access_key: str = Field("prt_local_access", alias="S3_ACCESS_KEY")
    s3_secret_key: str = Field("prt_local_secret", alias="S3_SECRET_KEY")
    s3_secure: bool = Field(False, alias="S3_SECURE")

    secret_key: str = Field("change-me", alias="SECRET_KEY")
    jwt_issuer: str = Field("prt-ot-doc", alias="JWT_ISSUER")
    jwt_audience: str = Field("prt-ot-doc-clients", alias="JWT_AUDIENCE")
    jwt_algorithm: str = Field("RS256", alias="JWT_ALG")
    jwt_access_ttl_minutes: int = Field(30, alias="JWT_ACCESS_TTL_MIN")
    jwt_refresh_ttl_days: int = Field(7, alias="JWT_REFRESH_TTL_D")
    jwt_private_key_pem: str = Field("", alias="PRIVATE_KEY_PEM")
    jwt_public_key_pem: str = Field("", alias="PUBLIC_KEY_PEM")

    libreoffice_bin: str = Field("soffice", alias="LIBREOFFICE_BIN")
    pdf_fallback: Literal["auto", "always", "never"] = Field("auto", alias="PDF_FALLBACK_MODE")
    pdf_libreoffice_timeout_seconds: int = Field(120, alias="PDF_LIBREOFFICE_TIMEOUT_SECONDS")
    pdf_libreoffice_max_attempts: int = Field(4, alias="PDF_LIBREOFFICE_MAX_ATTEMPTS")
    pdf_libreoffice_retry_backoff_seconds: float = Field(
        1.0, alias="PDF_LIBREOFFICE_RETRY_BACKOFF_SECONDS"
    )
    pdf_libreoffice_retry_backoff_max_seconds: float = Field(
        30.0, alias="PDF_LIBREOFFICE_RETRY_BACKOFF_MAX_SECONDS"
    )
    pdf_worker_queue: str = Field("pdf", alias="PDF_WORKER_QUEUE")
    pdf_worker_concurrency: int = Field(2, alias="PDF_WORKER_CONCURRENCY")

    redis_url: str = Field("redis://localhost:6379/0", alias="REDIS_URL")
    redis_result_url_env: str | None = Field(None, alias="REDIS_RESULT_URL")
    worker_queues: list[str] = Field(default_factory=lambda: ["default"], alias="WORKER_QUEUES")
    celery_task_soft_time_limit: int = Field(300, alias="CELERY_TASK_SOFT_TIME_LIMIT")
    celery_task_time_limit: int = Field(600, alias="CELERY_TASK_TIME_LIMIT")
    celery_task_max_retries: int = Field(5, alias="CELERY_TASK_MAX_RETRIES")
    celery_retry_backoff_seconds: int = Field(5, alias="CELERY_RETRY_BACKOFF_SECONDS")
    celery_retry_backoff_max_seconds: int = Field(300, alias="CELERY_RETRY_BACKOFF_MAX_SECONDS")
    outbox_poll_interval: float = Field(5.0, alias="OUTBOX_POLL_INTERVAL")
    log_level: str = Field("INFO", alias="LOG_LEVEL")
    log_json: bool = Field(True, alias="LOG_JSON")
    rate_limit_enabled: bool = Field(True, alias="RATE_LIMIT_ENABLED")
    rate_limit_storage_uri: str = Field("memory://", alias="RATE_LIMIT_STORAGE_URI")
    rate_limit_login_per_identity: str = Field("5/minute", alias="RATE_LIMIT_LOGIN_PER_IDENTITY")
    rate_limit_upload_per_tenant: str = Field("10/minute", alias="RATE_LIMIT_UPLOAD_PER_TENANT")

    use_1c_integration: bool = Field(False, alias="USE_1C_INTEGRATION")
    use_edo_integration: bool = Field(False, alias="USE_EDO_INTEGRATION")
    use_frdo_integration: bool = Field(False, alias="USE_FRDO_INTEGRATION")
    use_eisot_integration: bool = Field(False, alias="USE_EISOT_INTEGRATION")

    json_max_bytes: int = Field(JSON_MAX_DEFAULT, alias="JSON_MAX")
    max_upload_size: int = Field(
        MAX_UPLOAD_SIZE_DEFAULT,
        alias="MAX_UPLOAD_SIZE",
        validation_alias=AliasChoices("MAX_UPLOAD_SIZE", "MAX_UPLOAD_BYTES"),
    )
    file_allowed_mime: CsvMimeList = Field(
        default_factory=lambda: list(DEFAULT_ALLOWED_FILE_MIME),
        alias="FILE_ALLOWED_MIME",
    )
    file_allowed_extensions: CsvExtensionList = Field(
        default_factory=lambda: list(DEFAULT_ALLOWED_FILE_EXTENSIONS),
        alias="FILE_ALLOWED_EXTENSIONS",
    )

    clamav_queue_url: str = Field("memory://", alias="CLAMAV_QUEUE_URL")
    clamav_quarantine_queue: str = Field(
        "clamav.quarantine", alias="CLAMAV_QUARANTINE_QUEUE"
    )
    clamav_scan_queue: str = Field("clamav.scan", alias="CLAMAV_SCAN_QUEUE")
    clamav_host: str = Field("clamav", alias="CLAMAV_HOST")
    clamav_port: int = Field(3310, alias="CLAMAV_PORT")
    clamav_timeout: float = Field(30.0, alias="CLAMAV_TIMEOUT")
    clamav_unix_socket: str | None = Field(None, alias="CLAMAV_UNIX_SOCKET")

    enable_metrics: bool = Field(True, alias="ENABLE_METRICS")
    enable_gzip: bool = Field(True, alias="ENABLE_GZIP")
    max_request_body_bytes: int = Field(1_048_576, alias="MAX_REQUEST_BODY_BYTES")
    request_timeout_seconds: float = Field(15.0, alias="REQUEST_TIMEOUT_SECONDS")
    trace_header_name: str = Field("X-Trace-Id", alias="TRACE_HEADER_NAME")
    default_locale: str = Field("ru-RU", alias="DEFAULT_LOCALE")
    default_timezone: str = Field("Europe/Moscow", alias="DEFAULT_TIMEZONE")

    @field_validator("allowed_hosts", "allowed_origins", "worker_queues", mode="before")
    @classmethod
    def _coerce_sequence(
        cls,
        value: str | Sequence[str] | PydanticUndefinedType | None,
        info: ValidationInfo,
    ) -> list[str]:
        defaults = {
            "allowed_hosts": ["*"],
            "allowed_origins": ["*"],
            "worker_queues": ["default"],
        }

        default = defaults.get(info.field_name, [])
        return split_csv(value, default=default)

    @field_validator("libreoffice_bin")
    @classmethod
    def _validate_libreoffice_bin(cls, value: str) -> str:
        candidate = value.strip()
        if not candidate:
            raise ValueError("LIBREOFFICE_BIN cannot be empty")

        if not binary_exists(candidate):
            logger.warning(
                "LibreOffice binary '%s' not found in PATH or at provided location", candidate
            )

        return candidate

    @field_validator("default_tenant_slug")
    @classmethod
    def _validate_default_tenant_slug(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not normalized:
            msg = "DEFAULT_TENANT_SLUG must not be empty"
            raise ValueError(msg)
        allowed = set("abcdefghijklmnopqrstuvwxyz0123456789-_")
        if any(ch not in allowed for ch in normalized):
            msg = "DEFAULT_TENANT_SLUG contains invalid characters"
            raise ValueError(msg)
        return normalized

    @field_validator("shared_schema")
    @classmethod
    def _validate_shared_schema(cls, value: str) -> str:
        candidate = value.strip()
        if not candidate:
            msg = "SHARED_SCHEMA must not be empty"
            raise ValueError(msg)
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", candidate):
            msg = (
                "SHARED_SCHEMA must start with a letter or underscore "
                "and contain only alphanumerics or underscores"
            )
            raise ValueError(msg)
        return candidate

    @field_validator(
        "json_max_bytes",
        "max_upload_size",
        "celery_task_soft_time_limit",
        "celery_task_time_limit",
        "celery_task_max_retries",
        "celery_retry_backoff_seconds",
        "celery_retry_backoff_max_seconds",
        "pdf_libreoffice_timeout_seconds",
        "pdf_libreoffice_max_attempts",
        "pdf_worker_concurrency",
    )
    @classmethod
    def _validate_positive_sizes(cls, value: int, info: ValidationInfo) -> int:
        if value <= 0:
            raise ValueError(f"{info.field_name.upper()} must be greater than zero")
        return value

    @field_validator(
        "pdf_libreoffice_retry_backoff_seconds",
        "pdf_libreoffice_retry_backoff_max_seconds",
        mode="before",
    )
    @classmethod
    def _validate_positive_float(cls, value: float, info: ValidationInfo) -> float:
        if isinstance(value, str):
            value = float(value)
        if value <= 0:
            raise ValueError(f"{info.field_name.upper()} must be greater than zero")
        return float(value)

    @field_validator("pdf_worker_queue")
    @classmethod
    def _validate_pdf_worker_queue(cls, value: str) -> str:
        candidate = value.strip()
        if not candidate:
            raise ValueError("PDF_WORKER_QUEUE must not be empty")
        return candidate

    @model_validator(mode="after")
    def _ensure_worker_queues(self) -> "Settings":
        queues = []
        for queue in self.worker_queues:
            normalized = queue.strip()
            if normalized and normalized not in queues:
                queues.append(normalized)
        if self.pdf_worker_queue not in queues:
            queues.append(self.pdf_worker_queue)
        self.worker_queues = queues
        return self

    @model_validator(mode="after")
    def _ensure_jwt_keys(self) -> Settings:
        private_key = self.jwt_private_key_pem.strip()
        public_key = self.jwt_public_key_pem.strip()

        if private_key and public_key:
            self.jwt_private_key_pem = private_key
            self.jwt_public_key_pem = public_key
            return self

        if self.app_env == "production":
            raise SettingsError(
                "PRIVATE_KEY_PEM and PUBLIC_KEY_PEM must be configured in production"
            )

        logger.warning(
            (
                "Using bundled development RSA key pair for JWT signing; configure "
                "PRIVATE_KEY_PEM/PUBLIC_KEY_PEM in production"
            )
        )
        self.jwt_private_key_pem = DEV_PRIVATE_KEY
        self.jwt_public_key_pem = DEV_PUBLIC_KEY
        return self

    @property
    def application(self) -> ApplicationConfig:
        if self._application is None:
            self._application = ApplicationConfig(
                name=self.app_name,
                environment=self.app_env,
                debug=self.debug,
                secret_key=self.secret_key,
                api_prefix=self.api_prefix,
                api_v1_prefix=self.api_v1_prefix,
                allowed_hosts=list(self.allowed_hosts),
                allowed_origins=list(self.allowed_origins),
                default_locale=self.default_locale,
                default_timezone=self.default_timezone,
            )
        return self._application

    @property
    def runtime(self) -> RuntimeConfig:
        if self._runtime is None:
            self._runtime = self.application.runtime
        return self._runtime

    @property
    def database(self) -> DatabaseConfig:
        if self._database is None:
            self._database = DatabaseConfig(
                url=self.database_url,
                alembic_url=self.alembic_database_url,
                echo=self.database_echo,
                host=self.postgres_host,
                port=self.postgres_port,
                name=self.postgres_db,
                user=self.postgres_user,
                password=self.postgres_password,
            )
        return self._database

    @property
    def broker(self) -> BrokerConfig:
        if self._broker is None:
            self._broker = BrokerConfig(
                broker_url=self.redis_url,
                result_url=self.redis_result_url,
                rate_limit_storage_uri=self.rate_limit_storage_uri,
            )
        return self._broker

    @property
    def redis(self) -> BrokerConfig:
        """Backward compatible accessor for Redis/Celery broker settings."""

        return self.broker

    @property
    def celery(self) -> CeleryConfig:
        if self._celery is None:
            self._celery = CeleryConfig(
                worker_queues=list(self.worker_queues),
                pdf_queue=self.pdf_worker_queue,
                task_soft_time_limit=self.celery_task_soft_time_limit,
                task_time_limit=self.celery_task_time_limit,
                task_max_retries=self.celery_task_max_retries,
                retry_backoff_seconds=self.celery_retry_backoff_seconds,
                retry_backoff_max_seconds=self.celery_retry_backoff_max_seconds,
            )
        return self._celery

    @property
    def logging(self) -> LoggingConfig:
        if self._logging is None:
            self._logging = LoggingConfig(level=self.log_level, json_enabled=self.log_json)
        return self._logging

    @property
    def database_url(self) -> str:
        if self.database_url_env:
            return self.database_url_env
        return (
            "postgresql+asyncpg://"
            f"{self.postgres_user}:{self.postgres_password}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    @property
    def alembic_database_url(self) -> str:
        """Database URL used for Alembic migrations."""

        url = self.database_url
        if url.startswith("sqlite+aiosqlite"):
            return url.replace("+aiosqlite", "")
        if url.startswith("postgresql+asyncpg"):
            return url.replace("+asyncpg", "+psycopg2")
        return url

    @property
    def redis_result_url(self) -> str:
        """Return Celery result backend URL, defaulting to the broker URL."""

        return self.redis_result_url_env or self.redis_url


@lru_cache
def _load_settings() -> Settings:
    return Settings()


def get_settings(*, force_reload: bool = False) -> Settings:
    """Return cached application settings, reloading when requested."""

    if force_reload:
        _load_settings.cache_clear()
    return _load_settings()


def bootstrap(role: Literal["api", "worker"]) -> Settings:
    settings = get_settings(force_reload=True)
    configure_runtime_locale(
        locale_name=settings.application.default_locale,
        timezone_name=settings.application.default_timezone,
    )
    if settings.application.runtime.is_production and (
        not settings.application.secret_key or settings.application.secret_key == "change-me"
    ):
        raise SettingsError("SECRET_KEY must be configured")
    return settings


def reset_settings_cache() -> None:
    """Clear cached settings to force reload on next access."""

    _load_settings.cache_clear()


# Provide compatibility attribute used in tests expecting an lru_cache-style API.
get_settings.cache_clear = reset_settings_cache  # type: ignore[attr-defined]


__all__ = ["Settings", "SettingsError", "get_settings", "bootstrap", "reset_settings_cache"]


def split_csv(
    value: str | Sequence[str] | PydanticUndefinedType | None,
    *,
    default: Sequence[str],
) -> list[str]:
    """Normalize comma separated values to a list of strings."""

    if value is None or value is PydanticUndefined:
        return list(default)

    if isinstance(value, str):
        raw_items: Iterable[object] = value.split(",")
    elif isinstance(value, Sequence):
        raw_items = value
    else:
        try:
            raw_items = list(value)  # type: ignore[arg-type]
        except TypeError as exc:  # pragma: no cover - defensive programming
            raise TypeError("Expected string or sequence of strings") from exc

    normalized: list[str] = []
    for item in raw_items:
        if item is None:
            continue
        candidate = str(item).strip()
        if candidate:
            normalized.append(candidate)

    return normalized or list(default)


def binary_exists(candidate: str) -> bool:
    """Check whether the provided binary exists on disk or in ``PATH``."""

    path = Path(candidate)

    # Explicit path (absolute or contains directory components)
    if path.is_absolute() or path.name != candidate:
        return path.exists()

    resolved = which(candidate)
    if resolved is not None:
        return True

    return path.exists()
